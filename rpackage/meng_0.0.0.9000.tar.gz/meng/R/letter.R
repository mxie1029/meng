#' generating a letter
#'
#' sample from the alphabet
#'
#' @param x A useless parameter for the parallel computition
#' @return a random letter of the alphabet
#' @export

letter <- function(x){
 sample(letters,1)
}


